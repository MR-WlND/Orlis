<?php

namespace Tests\Feature;

// use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     */
    public function test_the_application_redirects_to_client_products_page(): void
    {
        $response = $this->get('/');

        $response->assertRedirect('/products');
    }
}
