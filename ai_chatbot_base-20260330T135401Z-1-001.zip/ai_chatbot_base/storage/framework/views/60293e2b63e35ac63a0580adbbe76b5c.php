<footer class="app-footer d-flex justify-content-between align-items-center">
    <span>WEB4014 PHP3 - Quản lý danh mục và sản phẩm</span>
    <span><?php echo e(date('Y')); ?></span>
</footer><?php /**PATH D:\PHP3\ai_chatbot\resources\views/partials/footer.blade.php ENDPATH**/ ?>