<aside class="sidebar">
    <div class="mb-4">
        <div class="fw-bold fs-5 text-white">Quản trị cửa hàng</div>
    </div>

    <a href="<?php echo e(route('categories.index')); ?>" class="<?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>">
        Danh mục admin
    </a>

    <a href="<?php echo e(route('products.index')); ?>" class="<?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>">
        Sản phẩm admin
    </a>
</aside><?php /**PATH C:\laragon\www\WEB4014_PHP3\ai_chatbot_base\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>