<?php $__env->startSection('title', 'Danh sách danh mục'); ?>
<?php $__env->startSection('page_title', 'Danh mục'); ?>
<?php $__env->startSection('page_subtitle', 'Danh sách và bộ lọc tìm kiếm'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h5 class="mb-0">Bộ lọc danh mục</h5>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('categories.trash')); ?>" class="btn btn-outline-danger">
                    <i class="bi bi-trash3 me-1"></i> Thùng rác
                </a>
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-lg me-1"></i> Thêm danh mục
                </a>
            </div>
        </div>

        <form method="GET" action="<?php echo e(route('categories.index')); ?>">
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="q" class="form-label">Từ khóa</label>
                    <input
                        type="text"
                        id="q"
                        name="q"
                        class="form-control"
                        value="<?php echo e($filters['q']); ?>"
                        placeholder="Tên, slug, mô tả..."
                    >
                </div>
                <div class="col-md-4">
                    <label for="sort" class="form-label">Sắp xếp</label>
                    <select id="sort" name="sort" class="form-select">
                        <option value="latest" <?php if($filters['sort'] === 'latest'): echo 'selected'; endif; ?>>Mới nhất</option>
                        <option value="oldest" <?php if($filters['sort'] === 'oldest'): echo 'selected'; endif; ?>>Cũ nhất</option>
                        <option value="name_asc" <?php if($filters['sort'] === 'name_asc'): echo 'selected'; endif; ?>>Tên A-Z</option>
                        <option value="name_desc" <?php if($filters['sort'] === 'name_desc'): echo 'selected'; endif; ?>>Tên Z-A</option>
                        <option value="updated_desc" <?php if($filters['sort'] === 'updated_desc'): echo 'selected'; endif; ?>>Cập nhật gần nhất</option>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end justify-content-md-end">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary icon-btn" title="Lọc dữ liệu">
                            <i class="bi bi-funnel-fill"></i>
                        </button>
                        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-secondary icon-btn" title="Xóa bộ lọc">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="panel">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên danh mục</th>
                    <th>Slug</th>
                    <th>Mô tả</th>
                    <th>Số sản phẩm</th>
                    <th class="text-end">Thao tác</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td class="fw-semibold"><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->slug); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($category->description, 60) ?: '-'); ?></td>
                        <td><?php echo e($category->products_count); ?></td>
                        <td class="text-end">
                            <div class="table-actions">
                                <a href="<?php echo e(route('categories.show', $category)); ?>" class="btn btn-sm btn-outline-primary icon-btn" title="Xem chi tiết">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('categories.edit', $category)); ?>" class="btn btn-sm btn-outline-warning icon-btn" title="Chỉnh sửa">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <form
                                    action="<?php echo e(route('categories.destroy', $category)); ?>"
                                    method="POST"
                                    class="d-inline"
                                    onsubmit="return confirm('Bạn muốn xóa mềm danh mục này?');"
                                >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger icon-btn" title="Xóa mềm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-secondary">Không có dữ liệu danh mục.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($categories->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP3\ai_chatbot\resources\views/categories/index.blade.php ENDPATH**/ ?>