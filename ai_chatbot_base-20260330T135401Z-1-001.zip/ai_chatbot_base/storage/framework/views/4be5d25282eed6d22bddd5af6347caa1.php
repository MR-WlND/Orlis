<?php $__env->startSection('title', 'Chi tiết sản phẩm'); ?>
<?php $__env->startSection('page_title', 'Chi tiết sản phẩm'); ?>
<?php $__env->startSection('page_subtitle', 'Xem đầy đủ thông tin sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">
            <div>
                <h4 class="mb-1"><?php echo e($product->name); ?></h4>
                <div class="text-secondary">Slug: <?php echo e($product->slug); ?></div>
            </div>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-warning">Sửa</a>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary">Quay lại</a>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-6">
                <div class="border rounded p-3 h-100">
                    <div class="text-secondary small">Danh mục</div>
                    <div class="fw-semibold">
                        <?php echo e($product->category?->name ?? 'Không xác định'); ?>

                        <?php if($product->category && $product->category->trashed()): ?>
                            <span class="badge text-bg-warning">Danh mục đã xóa mềm</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border rounded p-3 h-100">
                    <div class="text-secondary small">Giá</div>
                    <div class="fw-semibold"><?php echo e(number_format((float) $product->price, 0, ',', '.')); ?> đ</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border rounded p-3 h-100">
                    <div class="text-secondary small">Số lượng</div>
                    <div class="fw-semibold"><?php echo e($product->quantity); ?></div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <div class="text-secondary small">Ảnh</div>
                    <?php if($product->image): ?>
                        <div class="mb-2">
                            <img
                                src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                alt="<?php echo e($product->name); ?>"
                                class="rounded border"
                                style="max-width: 220px; max-height: 220px; object-fit: cover;"
                            >
                        </div>
                        <div class="text-secondary small"><?php echo e($product->image); ?></div>
                    <?php else: ?>
                        <div class="fw-semibold">Chưa có ảnh</div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <div class="text-secondary small">Mô tả</div>
                    <div class="fw-semibold"><?php echo e($product->description ?: 'Chưa có mô tả.'); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\WEB4014_PHP3\ai_chatbot_base\resources\views/products/show.blade.php ENDPATH**/ ?>