﻿

<?php $__env->startSection('title', 'Danh sách sản phẩm'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .product-card {
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        transition: 0.2s ease;
        height: 100%;
    }

    .product-card:hover {
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
        transform: translateY(-2px);
    }

    .product-link {
        color: inherit;
        text-decoration: none;
        display: block;
        height: 100%;
    }

    .product-image {
        height: 180px;
        object-fit: cover;
        border-top-left-radius: 14px;
        border-top-right-radius: 14px;
        background: #eef2ff;
    }

    .icon-btn {
        width: 40px;
        height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h2 class="mb-1">Danh sách sản phẩm</h2>
            <div class="text-secondary">Hiển thị toàn bộ sản phẩm cho khách hàng</div>
        </div>
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-primary">Vào trang quản trị</a>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('client.products.index')); ?>">
                <div class="row g-3 align-items-end">
                    <div class="col-md-5">
                        <label for="q" class="form-label">Từ khóa</label>
                        <input
                            type="text"
                            id="q"
                            name="q"
                            class="form-control"
                            value="<?php echo e($filters['q']); ?>"
                            placeholder="Tên sản phẩm, slug, mô tả..."
                        >
                    </div>
                    <div class="col-md-3">
                        <label for="category_id" class="form-label">Danh mục</label>
                        <select id="category_id" name="category_id" class="form-select">
                            <option value="">-- Tất cả danh mục --</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if((string) $filters['category_id'] === (string) $category->id): echo 'selected'; endif; ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="sort" class="form-label">Sắp xếp</label>
                        <select id="sort" name="sort" class="form-select">
                            <option value="latest" <?php if($filters['sort'] === 'latest'): echo 'selected'; endif; ?>>Mới nhất</option>
                            <option value="oldest" <?php if($filters['sort'] === 'oldest'): echo 'selected'; endif; ?>>Cũ nhất</option>
                            <option value="name_asc" <?php if($filters['sort'] === 'name_asc'): echo 'selected'; endif; ?>>Tên A-Z</option>
                            <option value="name_desc" <?php if($filters['sort'] === 'name_desc'): echo 'selected'; endif; ?>>Tên Z-A</option>
                            <option value="price_asc" <?php if($filters['sort'] === 'price_asc'): echo 'selected'; endif; ?>>Giá tăng dần</option>
                            <option value="price_desc" <?php if($filters['sort'] === 'price_desc'): echo 'selected'; endif; ?>>Giá giảm dần</option>
                        </select>
                    </div>
                    <div class="col-md-1 d-flex align-items-end justify-content-md-end">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary icon-btn" title="Lọc sản phẩm" aria-label="Lọc sản phẩm">
                                <i class="bi bi-funnel-fill"></i>
                            </button>
                            <a
                                href="<?php echo e(route('client.products.index')); ?>"
                                class="btn btn-outline-secondary icon-btn"
                                title="Xóa bộ lọc"
                                aria-label="Xóa bộ lọc"
                            >
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-sm-6 col-lg-4">
                <a href="<?php echo e(route('client.products.show', $product->slug)); ?>" class="product-link">
                    <div class="card product-card">
                        <?php if($product->image): ?>
                            <img
                                src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                alt="<?php echo e($product->name); ?>"
                                class="product-image w-100"
                            >
                        <?php else: ?>
                            <div class="product-image d-flex align-items-center justify-content-center text-secondary">
                                Chưa có ảnh
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <div class="text-secondary small mb-2"><?php echo e($product->category?->name); ?></div>
                            <h5 class="card-title mb-2"><?php echo e($product->name); ?></h5>
                            <div class="fw-bold text-primary mb-2">
                                <?php echo e(number_format((float) $product->price, 0, ',', '.')); ?> VND
                            </div>
                            <p class="card-text text-secondary mb-3">
                                <?php echo e(\Illuminate\Support\Str::limit($product->description, 90) ?: 'Không có mô tả.'); ?>

                            </p>
                            <div class="small text-secondary mb-0">Còn lại: <?php echo e($product->quantity); ?> sản phẩm</div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-warning mb-0">Không tìm thấy sản phẩm phù hợp.</div>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4">
        <?php echo e($products->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\WEB4014_PHP3\ai_chatbot_base\resources\views/client/products/index.blade.php ENDPATH**/ ?>