<footer class="app-footer d-flex justify-content-between align-items-center">
    <span>WEB4014 PHP3 - Quản lý danh mục và sản phẩm</span>
    <span><?php echo e(date('Y')); ?></span>
</footer><?php /**PATH C:\laragon\www\WEB4014_PHP3\ai_chatbot_base\resources\views/partials/footer.blade.php ENDPATH**/ ?>