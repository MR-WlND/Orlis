<header class="app-header d-flex justify-content-between align-items-center gap-3">
    <div>
        <div class="fw-semibold"><?php echo $__env->yieldContent('page_title', 'Quản lý dữ liệu'); ?></div>
        <div class="text-secondary small"><?php echo $__env->yieldContent('page_subtitle', 'Danh mục và sản phẩm'); ?></div>
    </div>
    <div class="text-secondary small">
        Cập nhật: <?php echo e(now()->format('d/m/Y H:i')); ?>

    </div>
</header><?php /**PATH D:\PHP3\ai_chatbot\resources\views/partials/header.blade.php ENDPATH**/ ?>