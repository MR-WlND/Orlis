<?php $__env->startSection('title', 'Cập nhật sản phẩm'); ?>
<?php $__env->startSection('page_title', 'Cập nhật sản phẩm'); ?>
<?php $__env->startSection('page_subtitle', 'Chỉnh sửa thông tin sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <h5 class="mb-3">Thông tin sản phẩm #<?php echo e($product->id); ?></h5>

        <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('products._form', [
                'submitLabel' => 'Cập nhật sản phẩm',
                'product' => $product,
                'categories' => $categories,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\WEB4014_PHP3\ai_chatbot_base\resources\views/products/edit.blade.php ENDPATH**/ ?>