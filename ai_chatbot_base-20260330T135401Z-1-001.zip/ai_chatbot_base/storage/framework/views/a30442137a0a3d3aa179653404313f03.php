<?php $__env->startSection('title', 'Danh sách sản phẩm'); ?>
<?php $__env->startSection('page_title', 'Sản phẩm'); ?>
<?php $__env->startSection('page_subtitle', 'Danh sách và bộ lọc tìm kiếm'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h5 class="mb-0">Bộ lọc sản phẩm</h5>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('products.trash')); ?>" class="btn btn-outline-danger">
                    <i class="bi bi-trash3 me-1"></i> Thùng rác
                </a>
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-lg me-1"></i> Thêm sản phẩm
                </a>
            </div>
        </div>

        <form method="GET" action="<?php echo e(route('products.index')); ?>">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="q" class="form-label">Từ khóa</label>
                    <input
                        type="text"
                        id="q"
                        name="q"
                        class="form-control"
                        value="<?php echo e($filters['q']); ?>"
                        placeholder="Tên, slug, mô tả..."
                    >
                </div>
                <div class="col-md-3">
                    <label for="category_id" class="form-label">Danh mục</label>
                    <select id="category_id" name="category_id" class="form-select">
                        <option value="">-- Tất cả danh mục --</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if((string) $filters['category_id'] === (string) $category->id): echo 'selected'; endif; ?>>
                                <?php echo e($category->name); ?><?php echo e($category->deleted_at ? ' (đã xóa mềm)' : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="sort" class="form-label">Sắp xếp</label>
                    <select id="sort" name="sort" class="form-select">
                        <option value="latest" <?php if($filters['sort'] === 'latest'): echo 'selected'; endif; ?>>Mới nhất</option>
                        <option value="oldest" <?php if($filters['sort'] === 'oldest'): echo 'selected'; endif; ?>>Cũ nhất</option>
                        <option value="name_asc" <?php if($filters['sort'] === 'name_asc'): echo 'selected'; endif; ?>>Tên A-Z</option>
                        <option value="name_desc" <?php if($filters['sort'] === 'name_desc'): echo 'selected'; endif; ?>>Tên Z-A</option>
                        <option value="price_asc" <?php if($filters['sort'] === 'price_asc'): echo 'selected'; endif; ?>>Giá tăng dần</option>
                        <option value="price_desc" <?php if($filters['sort'] === 'price_desc'): echo 'selected'; endif; ?>>Giá giảm dần</option>
                        <option value="quantity_asc" <?php if($filters['sort'] === 'quantity_asc'): echo 'selected'; endif; ?>>Số lượng tăng</option>
                        <option value="quantity_desc" <?php if($filters['sort'] === 'quantity_desc'): echo 'selected'; endif; ?>>Số lượng giảm</option>
                        <option value="updated_desc" <?php if($filters['sort'] === 'updated_desc'): echo 'selected'; endif; ?>>Cập nhật gần nhất</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end justify-content-md-end">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary icon-btn" title="Lọc dữ liệu">
                            <i class="bi bi-funnel-fill"></i>
                        </button>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary icon-btn" title="Xóa bộ lọc">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="panel">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên sản phẩm</th>
                    <th>Danh mục</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Ảnh</th>
                    <th class="text-end">Thao tác</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td class="fw-semibold"><?php echo e($product->name); ?></td>
                        <td>
                            <?php echo e($product->category?->name ?? 'Không xác định'); ?>

                            <?php if($product->category && $product->category->trashed()): ?>
                                <span class="badge text-bg-warning">Danh mục đã xóa mềm</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(number_format((float) $product->price, 0, ',', '.')); ?> đ</td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td>
                            <?php if($product->image): ?>
                                <img
                                    src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                    alt="<?php echo e($product->name); ?>"
                                    class="rounded border"
                                    style="width: 50px; height: 50px; object-fit: cover;"
                                >
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <div class="table-actions">
                                <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-sm btn-outline-primary icon-btn" title="Xem chi tiết">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-outline-warning icon-btn" title="Chỉnh sửa">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <form
                                    action="<?php echo e(route('products.destroy', $product)); ?>"
                                    method="POST"
                                    class="d-inline"
                                    onsubmit="return confirm('Bạn muốn xóa mềm sản phẩm này?');"
                                >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger icon-btn" title="Xóa mềm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-secondary">Không có dữ liệu sản phẩm.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($products->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\WEB4014_PHP3\ai_chatbot_base\resources\views/products/index.blade.php ENDPATH**/ ?>