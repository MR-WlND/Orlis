<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ClientProductController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/products');
Route::redirect('/admin', '/admin/categories');

Route::get('/products', [ClientProductController::class, 'index'])->name('client.products.index');
Route::get('/products/{slug}', [ClientProductController::class, 'show'])->name('client.products.show');

Route::prefix('admin')->group(function (): void {
    Route::get('categories/trash', [CategoryController::class, 'trash'])->name('categories.trash');
    Route::patch('categories/{id}/restore', [CategoryController::class, 'restore'])->name('categories.restore');
    Route::delete('categories/{id}/force-delete', [CategoryController::class, 'forceDelete'])->name('categories.force-delete');
    Route::resource('categories', CategoryController::class);

    Route::get('products/trash', [ProductController::class, 'trash'])->name('products.trash');
    Route::patch('products/{id}/restore', [ProductController::class, 'restore'])->name('products.restore');
    Route::delete('products/{id}/force-delete', [ProductController::class, 'forceDelete'])->name('products.force-delete');
    Route::resource('products', ProductController::class);
});
