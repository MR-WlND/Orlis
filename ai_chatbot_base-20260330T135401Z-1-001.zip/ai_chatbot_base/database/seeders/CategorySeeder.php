<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $now = now();

        $categories = [
            [
                'name' => 'Điện thoại',
                'slug' => 'dien-thoai',
                'description' => 'Danh mục các dòng điện thoại thông minh mới nhất.',
            ],
            [
                'name' => 'Laptop',
                'slug' => 'laptop',
                'description' => 'Laptop phục vụ văn phòng, học tập và chơi game.',
            ],
            [
                'name' => 'Máy tính bảng',
                'slug' => 'may-tinh-bang',
                'description' => 'Máy tính bảng phục vụ giải trí, học tập và làm việc.',
            ],
            [
                'name' => 'Phụ kiện',
                'slug' => 'phu-kien',
                'description' => 'Phụ kiện công nghệ như tai nghe, pin sạc dự phòng.',
            ],
        ];

        $payload = array_map(
            fn (array $category) => [
                ...$category,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            $categories
        );

        DB::table('categories')->upsert(
            $payload,
            ['slug'],
            ['name', 'description', 'updated_at']
        );
    }
}
