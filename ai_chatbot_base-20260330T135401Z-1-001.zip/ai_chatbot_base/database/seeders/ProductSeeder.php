<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = DB::table('categories')->pluck('id', 'slug');

        if ($categories->isEmpty()) {
            return;
        }

        $now = now();

        $products = [
            [
                'name' => 'Điện thoại iPhone 16 Pro 128GB',
                'slug' => 'iphone-16-pro-128gb',
                'description' => 'Màn hình OLED, chip A-series mới và camera nâng cấp.',
                'price' => 28990000,
                'quantity' => 15,
                'image' => 'products/iphone-16-pro.jpg',
                'category_id' => $categories['dien-thoai'] ?? null,
            ],
            [
                'name' => 'Điện thoại Samsung Galaxy S26 256GB',
                'slug' => 'samsung-galaxy-s26-256gb',
                'description' => 'Điện thoại Android cao cấp với hệ thống camera AI.',
                'price' => 24990000,
                'quantity' => 20,
                'image' => 'products/galaxy-s26.jpg',
                'category_id' => $categories['dien-thoai'] ?? null,
            ],
            [
                'name' => 'Laptop MacBook Air M4 13 inch',
                'slug' => 'macbook-air-m4-13-inch',
                'description' => 'Laptop mỏng nhẹ, phù hợp học tập và công việc hằng ngày.',
                'price' => 31990000,
                'quantity' => 10,
                'image' => 'products/macbook-air-m4.jpg',
                'category_id' => $categories['laptop'] ?? null,
            ],
            [
                'name' => 'Laptop Dell XPS 14',
                'slug' => 'dell-xps-14',
                'description' => 'Laptop cao cấp cho lập trình viên và nhà thiết kế.',
                'price' => 42990000,
                'quantity' => 7,
                'image' => 'products/dell-xps-14.jpg',
                'category_id' => $categories['laptop'] ?? null,
            ],
            [
                'name' => 'Máy tính bảng iPad Air 11 Wi-Fi',
                'slug' => 'ipad-air-11-wifi',
                'description' => 'Máy tính bảng cho học tập, ghi chú và giải trí.',
                'price' => 16990000,
                'quantity' => 18,
                'image' => 'products/ipad-air-11.jpg',
                'category_id' => $categories['may-tinh-bang'] ?? null,
            ],
            [
                'name' => 'Máy tính bảng Samsung Galaxy Tab S10',
                'slug' => 'samsung-galaxy-tab-s10',
                'description' => 'Màn hình lớn, phù hợp giải trí và làm việc đa nhiệm.',
                'price' => 19990000,
                'quantity' => 12,
                'image' => 'products/tab-s10.jpg',
                'category_id' => $categories['may-tinh-bang'] ?? null,
            ],
            [
                'name' => 'Tai nghe AirPods Pro Gen 3',
                'slug' => 'airpods-pro-gen-3',
                'description' => 'Tai nghe không dây với chống ồn chủ động.',
                'price' => 6490000,
                'quantity' => 30,
                'image' => 'products/airpods-pro-gen-3.jpg',
                'category_id' => $categories['phu-kien'] ?? null,
            ],
            [
                'name' => 'Pin sạc dự phòng 20.000mAh',
                'slug' => 'pin-sac-du-phong-20000mah',
                'description' => 'Hỗ trợ sạc nhanh, dung lượng lớn cho nhiều thiết bị.',
                'price' => 890000,
                'quantity' => 50,
                'image' => 'products/pin-sac-du-phong-20000mah.jpg',
                'category_id' => $categories['phu-kien'] ?? null,
            ],
        ];

        $payload = array_values(array_filter($products, fn (array $product) => ! empty($product['category_id'])));
        $payload = array_map(
            fn (array $product) => [
                ...$product,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            $payload
        );

        DB::table('products')->upsert(
            $payload,
            ['slug'],
            ['name', 'description', 'price', 'quantity', 'image', 'category_id', 'updated_at']
        );
    }
}
