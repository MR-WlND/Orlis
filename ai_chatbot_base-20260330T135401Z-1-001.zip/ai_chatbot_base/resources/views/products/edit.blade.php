@extends('layouts.app')

@section('title', 'Cập nhật sản phẩm')
@section('page_title', 'Cập nhật sản phẩm')
@section('page_subtitle', 'Chỉnh sửa thông tin sản phẩm')

@section('content')
    <div class="panel">
        <h5 class="mb-3">Thông tin sản phẩm #{{ $product->id }}</h5>

        <form action="{{ route('products.update', $product) }}" method="POST" enctype="multipart/form-data">
            @method('PUT')
            @include('products._form', [
                'submitLabel' => 'Cập nhật sản phẩm',
                'product' => $product,
                'categories' => $categories,
            ])
        </form>
    </div>
@endsection
