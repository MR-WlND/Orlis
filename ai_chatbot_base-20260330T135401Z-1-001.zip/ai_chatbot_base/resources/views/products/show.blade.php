@extends('layouts.app')

@section('title', 'Chi tiết sản phẩm')
@section('page_title', 'Chi tiết sản phẩm')
@section('page_subtitle', 'Xem đầy đủ thông tin sản phẩm')

@section('content')
    <div class="panel">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">
            <div>
                <h4 class="mb-1">{{ $product->name }}</h4>
                <div class="text-secondary">Slug: {{ $product->slug }}</div>
            </div>
            <div class="d-flex gap-2">
                <a href="{{ route('products.edit', $product) }}" class="btn btn-warning">Sửa</a>
                <a href="{{ route('products.index') }}" class="btn btn-outline-secondary">Quay lại</a>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-6">
                <div class="border rounded p-3 h-100">
                    <div class="text-secondary small">Danh mục</div>
                    <div class="fw-semibold">
                        {{ $product->category?->name ?? 'Không xác định' }}
                        @if ($product->category && $product->category->trashed())
                            <span class="badge text-bg-warning">Danh mục đã xóa mềm</span>
                        @endif
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border rounded p-3 h-100">
                    <div class="text-secondary small">Giá</div>
                    <div class="fw-semibold">{{ number_format((float) $product->price, 0, ',', '.') }} đ</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border rounded p-3 h-100">
                    <div class="text-secondary small">Số lượng</div>
                    <div class="fw-semibold">{{ $product->quantity }}</div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <div class="text-secondary small">Ảnh</div>
                    @if ($product->image)
                        <div class="mb-2">
                            <img
                                src="{{ asset('storage/' . $product->image) }}"
                                alt="{{ $product->name }}"
                                class="rounded border"
                                style="max-width: 220px; max-height: 220px; object-fit: cover;"
                            >
                        </div>
                        <div class="text-secondary small">{{ $product->image }}</div>
                    @else
                        <div class="fw-semibold">Chưa có ảnh</div>
                    @endif
                </div>
            </div>
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <div class="text-secondary small">Mô tả</div>
                    <div class="fw-semibold">{{ $product->description ?: 'Chưa có mô tả.' }}</div>
                </div>
            </div>
        </div>
    </div>
@endsection
