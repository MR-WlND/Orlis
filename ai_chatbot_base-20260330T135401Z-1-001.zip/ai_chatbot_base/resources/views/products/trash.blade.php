@extends('layouts.app')

@section('title', 'Thùng rác sản phẩm')
@section('page_title', 'Thùng rác sản phẩm')
@section('page_subtitle', 'Khôi phục hoặc xóa vĩnh viễn')

@section('content')
    <div class="panel mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h5 class="mb-0">Bộ lọc sản phẩm đã xóa mềm</h5>
            <a href="{{ route('products.index') }}" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
            </a>
        </div>

        <form method="GET" action="{{ route('products.trash') }}">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="q" class="form-label">Từ khóa</label>
                    <input
                        type="text"
                        id="q"
                        name="q"
                        class="form-control"
                        value="{{ $filters['q'] }}"
                        placeholder="Tên, slug, mô tả..."
                    >
                </div>
                <div class="col-md-3">
                    <label for="category_id" class="form-label">Danh mục</label>
                    <select id="category_id" name="category_id" class="form-select">
                        <option value="">-- Tất cả danh mục --</option>
                        @foreach ($categories as $category)
                            <option value="{{ $category->id }}" @selected((string) $filters['category_id'] === (string) $category->id)>
                                {{ $category->name }}{{ $category->deleted_at ? ' (đã xóa mềm)' : '' }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="sort" class="form-label">Sắp xếp</label>
                    <select id="sort" name="sort" class="form-select">
                        <option value="latest" @selected($filters['sort'] === 'latest')>Mới xóa gần đây</option>
                        <option value="oldest" @selected($filters['sort'] === 'oldest')>Cũ nhất</option>
                        <option value="name_asc" @selected($filters['sort'] === 'name_asc')>Tên A-Z</option>
                        <option value="name_desc" @selected($filters['sort'] === 'name_desc')>Tên Z-A</option>
                        <option value="price_asc" @selected($filters['sort'] === 'price_asc')>Giá tăng dần</option>
                        <option value="price_desc" @selected($filters['sort'] === 'price_desc')>Giá giảm dần</option>
                        <option value="quantity_asc" @selected($filters['sort'] === 'quantity_asc')>Số lượng tăng</option>
                        <option value="quantity_desc" @selected($filters['sort'] === 'quantity_desc')>Số lượng giảm</option>
                        <option value="updated_desc" @selected($filters['sort'] === 'updated_desc')>Cập nhật gần nhất</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end justify-content-md-end">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary icon-btn" title="Lọc dữ liệu">
                            <i class="bi bi-funnel-fill"></i>
                        </button>
                        <a href="{{ route('products.trash') }}" class="btn btn-outline-secondary icon-btn" title="Xóa bộ lọc">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="panel">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên sản phẩm</th>
                    <th>Danh mục</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Ảnh</th>
                    <th class="text-end">Thao tác</th>
                </tr>
                </thead>
                <tbody>
                @forelse ($products as $product)
                    <tr>
                        <td>{{ $product->id }}</td>
                        <td class="fw-semibold">{{ $product->name }}</td>
                        <td>
                            {{ $product->category?->name ?? 'Không xác định' }}
                            @if ($product->category && $product->category->trashed())
                                <span class="badge text-bg-warning">Danh mục đã xóa mềm</span>
                            @endif
                        </td>
                        <td>{{ number_format((float) $product->price, 0, ',', '.') }} đ</td>
                        <td>{{ $product->quantity }}</td>
                        <td>
                            @if ($product->image)
                                <img
                                    src="{{ asset('storage/' . $product->image) }}"
                                    alt="{{ $product->name }}"
                                    class="rounded border"
                                    style="width: 50px; height: 50px; object-fit: cover;"
                                >
                            @else
                                -
                            @endif
                        </td>
                        <td class="text-end">
                            <div class="table-actions">
                                <form action="{{ route('products.restore', $product->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('PATCH')
                                    <button type="submit" class="btn btn-sm btn-outline-success icon-btn" title="Khôi phục">
                                        <i class="bi bi-arrow-counterclockwise"></i>
                                    </button>
                                </form>

                                <form
                                    action="{{ route('products.force-delete', $product->id) }}"
                                    method="POST"
                                    class="d-inline"
                                    onsubmit="return confirm('Bạn chắc chắn muốn xóa vĩnh viễn sản phẩm này?');"
                                >
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger icon-btn" title="Xóa vĩnh viễn">
                                        <i class="bi bi-trash3-fill"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="text-center text-secondary">Thùng rác đang trống.</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $products->links() }}
        </div>
    </div>
@endsection
