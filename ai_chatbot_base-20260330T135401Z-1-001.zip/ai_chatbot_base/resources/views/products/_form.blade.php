@csrf

<div class="mb-3">
    <label for="name" class="form-label">Tên sản phẩm <span class="text-danger">*</span></label>
    <input
        type="text"
        id="name"
        name="name"
        class="form-control @error('name') is-invalid @enderror"
        value="{{ old('name', $product->name ?? '') }}"
        required
    >
    @error('name')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<div class="row g-3">
    <div class="col-md-6">
        <label for="slug" class="form-label">Slug (tự động theo tên)</label>
        <input
            type="text"
            id="slug"
            name="slug"
            class="form-control"
            value="{{ old('slug', $product->slug ?? '') }}"
            readonly
        >
    </div>
    <div class="col-md-6">
        <label for="category_id" class="form-label">Danh mục <span class="text-danger">*</span></label>
        <select id="category_id" name="category_id" class="form-select @error('category_id') is-invalid @enderror" required>
            <option value="">-- Chọn danh mục --</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}" @selected((string) old('category_id', $product->category_id ?? '') === (string) $category->id)>
                    {{ $category->name }}{{ !empty($category->deleted_at) ? ' (đã xóa mềm)' : '' }}
                </option>
            @endforeach
        </select>
        @error('category_id')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
</div>

<div class="row g-3 mt-1">
    <div class="col-md-4">
        <label for="price" class="form-label">Giá <span class="text-danger">*</span></label>
        <input
            type="number"
            id="price"
            name="price"
            step="0.01"
            min="0"
            class="form-control @error('price') is-invalid @enderror"
            value="{{ old('price', isset($product) ? (float) $product->price : '') }}"
            required
        >
        @error('price')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
    <div class="col-md-4">
        <label for="quantity" class="form-label">Số lượng <span class="text-danger">*</span></label>
        <input
            type="number"
            id="quantity"
            name="quantity"
            min="0"
            class="form-control @error('quantity') is-invalid @enderror"
            value="{{ old('quantity', $product->quantity ?? 0) }}"
            required
        >
        @error('quantity')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
    <div class="col-md-4">
        <label for="image_file" class="form-label">Ảnh sản phẩm</label>
        <input
            type="file"
            id="image_file"
            name="image_file"
            class="form-control @error('image_file') is-invalid @enderror"
            accept="image/*"
        >
        @error('image_file')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
        <div class="form-text">Định dạng: jpg, jpeg, png, webp, gif. Tối đa 2MB.</div>
    </div>
</div>

@if (!empty($product?->image))
    <div class="mt-3">
        <div class="text-secondary small mb-2">Ảnh hiện tại</div>
        <img
            src="{{ asset('storage/' . $product->image) }}"
            alt="Ảnh sản phẩm"
            class="rounded border"
            style="width: 120px; height: 120px; object-fit: cover;"
        >
    </div>
@endif

<div class="mb-3 mt-3">
    <label for="description" class="form-label">Mô tả</label>
    <textarea
        id="description"
        name="description"
        class="form-control @error('description') is-invalid @enderror"
        rows="4"
    >{{ old('description', $product->description ?? '') }}</textarea>
    @error('description')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<div class="d-flex gap-2">
    <button type="submit" class="btn btn-primary">{{ $submitLabel }}</button>
    <a href="{{ route('products.index') }}" class="btn btn-outline-secondary">Quay lại</a>
</div>

@push('scripts')
<script>
    (function () {
        const nameInput = document.getElementById('name');
        const slugInput = document.getElementById('slug');

        if (!nameInput || !slugInput) {
            return;
        }

        const slugify = (value) => value
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/g, 'd')
            .replace(/[^a-z0-9\s-]/g, '')
            .trim()
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-');

        const syncSlug = () => {
            slugInput.value = slugify(nameInput.value);
        };

        if (!slugInput.value) {
            syncSlug();
        }

        nameInput.addEventListener('input', syncSlug);
    })();
</script>
@endpush