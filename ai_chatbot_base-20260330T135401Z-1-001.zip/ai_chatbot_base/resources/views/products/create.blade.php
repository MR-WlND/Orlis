@extends('layouts.app')

@section('title', 'Thêm sản phẩm')
@section('page_title', 'Thêm sản phẩm')
@section('page_subtitle', 'Tạo mới sản phẩm trong hệ thống')

@section('content')
    <div class="panel">
        <h5 class="mb-3">Thông tin sản phẩm</h5>

        <form action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data">
            @include('products._form', [
                'submitLabel' => 'Lưu sản phẩm',
                'categories' => $categories,
            ])
        </form>
    </div>
@endsection
