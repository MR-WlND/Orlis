<aside class="sidebar">
    <div class="mb-4">
        <div class="fw-bold fs-5 text-white">Quản trị cửa hàng</div>
    </div>

    <a href="{{ route('categories.index') }}" class="{{ request()->routeIs('categories.*') ? 'active' : '' }}">
        Danh mục admin
    </a>

    <a href="{{ route('products.index') }}" class="{{ request()->routeIs('products.*') ? 'active' : '' }}">
        Sản phẩm admin
    </a>
</aside>