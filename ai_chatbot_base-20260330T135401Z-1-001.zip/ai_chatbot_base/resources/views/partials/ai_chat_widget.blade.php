﻿<style>
    .ai-chat-widget {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 1080;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 10px;
    }

    .ai-chat-toggle {
        border: 0;
        border-radius: 999px;
        background: linear-gradient(135deg, #2563eb, #0ea5e9);
        color: #fff;
        height: 58px;
        padding: 0 18px;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        box-shadow: 0 14px 32px rgba(37, 99, 235, 0.35);
        transition: 0.2s ease;
    }

    .ai-chat-toggle:hover {
        transform: translateY(-1px);
        box-shadow: 0 18px 34px rgba(37, 99, 235, 0.4);
    }

    .ai-chat-toggle.is-hidden {
        display: none;
    }

    .ai-chat-toggle i {
        font-size: 20px;
    }

    .ai-chat-panel {
        width: min(390px, calc(100vw - 24px));
        height: min(620px, 72vh);
        border-radius: 16px;
        border: 1px solid #dbeafe;
        background: #fff;
        box-shadow: 0 20px 50px rgba(15, 23, 42, 0.25);
        overflow: hidden;
        display: none;
        flex-direction: column;
    }

    .ai-chat-panel.is-open {
        display: flex;
    }

    .ai-chat-header {
        background: linear-gradient(135deg, #1d4ed8, #0284c7);
        color: #fff;
        padding: 12px 14px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
    }

    .ai-chat-title {
        margin: 0;
        font-size: 15px;
        font-weight: 600;
        line-height: 1.2;
    }

    .ai-chat-subtitle {
        margin-top: 2px;
        display: block;
        font-size: 12px;
        opacity: 0.9;
    }

    .ai-chat-close {
        border: 0;
        width: 34px;
        height: 34px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.2);
        color: #fff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .ai-chat-log {
        flex: 1;
        overflow-y: auto;
        background: #f8fafc;
        padding: 12px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .ai-chat-row {
        display: flex;
    }

    .ai-chat-row.is-user {
        justify-content: flex-end;
    }

    .ai-chat-bubble {
        max-width: 90%;
        border-radius: 14px;
        padding: 10px 12px;
        font-size: 14px;
        line-height: 1.45;
        word-wrap: break-word;
    }

    .ai-chat-bubble.bot {
        background: #fff;
        border: 1px solid #e2e8f0;
        color: #0f172a;
    }

    .ai-chat-bubble.user {
        background: #2563eb;
        color: #fff;
    }

    .ai-chat-quick {
        border-top: 1px solid #e2e8f0;
        background: #fff;
        padding: 10px 10px 6px;
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
    }

    .ai-chat-form {
        border-top: 1px solid #e2e8f0;
        background: #fff;
        padding: 10px;
        display: flex;
        gap: 8px;
    }

    .ai-chat-input {
        flex: 1;
    }

    .ai-chat-send {
        min-width: 90px;
    }

    .ai-typing {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        min-height: 18px;
    }

    .ai-typing span {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #94a3b8;
        animation: ai-pulse 1.1s infinite ease-in-out;
    }

    .ai-typing span:nth-child(2) {
        animation-delay: 0.15s;
    }

    .ai-typing span:nth-child(3) {
        animation-delay: 0.3s;
    }

    @keyframes ai-pulse {
        0%,
        80%,
        100% {
            transform: scale(0.8);
            opacity: 0.5;
        }
        40% {
            transform: scale(1);
            opacity: 1;
        }
    }

    @media (max-width: 767px) {
        .ai-chat-widget {
            right: 12px;
            bottom: 12px;
        }

        .ai-chat-panel {
            width: min(420px, calc(100vw - 16px));
            height: min(78vh, 620px);
        }

        .ai-chat-toggle {
            height: 54px;
            padding: 0 15px;
        }
    }
</style>

<div class="ai-chat-widget" aria-live="polite">
    <button id="ai-chat-toggle" class="ai-chat-toggle" type="button" aria-label="Mở trợ lý chat">
        <i class="bi bi-chat-dots-fill"></i>
        <span>Hỗ trợ nhanh</span>
    </button>

    <section id="ai-chat-panel" class="ai-chat-panel" aria-hidden="true">
        <header class="ai-chat-header">
            <div>
                <h6 class="ai-chat-title">Demo Chat Widget</h6>
                <span class="ai-chat-subtitle">Chỉ giao diện, chưa kết nối AI</span>
            </div>
            <button id="ai-chat-close" class="ai-chat-close" type="button" aria-label="Đóng chat">
                <i class="bi bi-x-lg"></i>
            </button>
        </header>

        <div id="ai-chat-log" class="ai-chat-log">
            <div class="ai-chat-row is-bot">
                <div class="ai-chat-bubble bot">
                    Xin chào! Widget này đang ở chế độ demo workshop. Logic AI đã được gỡ bỏ.
                </div>
            </div>
        </div>

        <div class="ai-chat-quick">
            <button type="button" class="btn btn-sm btn-outline-secondary ai-example" data-prompt="tim laptop duoi 30000000">Laptop dưới 30 triệu</button>
            <button type="button" class="btn btn-sm btn-outline-secondary ai-example" data-prompt="tim phu kien gia mem">Phụ kiện giá mềm</button>
            <button type="button" class="btn btn-sm btn-outline-secondary ai-example" data-prompt="san pham nao gia cao nhat">Sản phẩm đắt nhất</button>
        </div>

        <form id="ai-assistant-form" class="ai-chat-form">
            <input
                id="ai-message"
                name="message"
                type="text"
                class="form-control ai-chat-input"
                placeholder="Nhập nội dung cần hỗ trợ..."
                required
            >
            <button id="ai-submit" type="submit" class="btn btn-primary ai-chat-send">
                <span id="ai-submit-text">Gửi</span>
                <span id="ai-loading" class="spinner-border spinner-border-sm ms-1 d-none" role="status" aria-hidden="true"></span>
            </button>
        </form>
    </section>
</div>

<script>
    (function () {
        const chatToggle = document.getElementById('ai-chat-toggle');
        const chatPanel = document.getElementById('ai-chat-panel');
        const chatClose = document.getElementById('ai-chat-close');
        const logBox = document.getElementById('ai-chat-log');
        const form = document.getElementById('ai-assistant-form');
        const messageInput = document.getElementById('ai-message');
        const submitButton = document.getElementById('ai-submit');
        const submitText = document.getElementById('ai-submit-text');
        const loading = document.getElementById('ai-loading');
        const exampleButtons = document.querySelectorAll('.ai-example');

        if (!chatToggle || !chatPanel || !chatClose || !logBox || !form || !messageInput || !submitButton || !submitText || !loading) {
            return;
        }

        const escapeHtml = (value) => String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');

        const scrollToBottom = () => {
            logBox.scrollTop = logBox.scrollHeight;
        };

        const openPanel = () => {
            chatPanel.classList.add('is-open');
            chatPanel.setAttribute('aria-hidden', 'false');
            chatToggle.classList.add('is-hidden');
            messageInput.focus();
            scrollToBottom();
        };

        const closePanel = () => {
            chatPanel.classList.remove('is-open');
            chatPanel.setAttribute('aria-hidden', 'true');
            chatToggle.classList.remove('is-hidden');
        };

        const appendBubble = (role, htmlContent) => {
            const row = document.createElement('div');
            row.className = `ai-chat-row ${role === 'user' ? 'is-user' : 'is-bot'}`;
            row.innerHTML = `<div class="ai-chat-bubble ${role === 'user' ? 'user' : 'bot'}">${htmlContent}</div>`;
            logBox.appendChild(row);
            scrollToBottom();
            return row;
        };

        const appendLoadingBubble = () => appendBubble('bot', '<div class="ai-typing"><span></span><span></span><span></span></div>');

        const setLoading = (isLoading) => {
            submitButton.disabled = isLoading;
            loading.classList.toggle('d-none', !isLoading);
            submitText.textContent = isLoading ? 'Đang gửi' : 'Gửi';
        };

        const buildLocalReply = (message) => {
            const lower = message.toLowerCase();

            if (lower.includes('laptop')) {
                return 'Chế độ demo: Trong workshop, bạn sẽ nối nội dung này với bộ lọc sản phẩm laptop ở backend.';
            }

            if (lower.includes('phu kien') || lower.includes('accessories')) {
                return 'Chế độ demo: Bước tiếp theo là ánh xạ văn bản này sang bộ lọc loại & giá sản phẩm.';
            }

            return 'Chế độ demo: Logic tìm kiếm AI đã được gỡ bỏ. Giao diện đã sẵn sàng để bạn triển khai backend trong workshop.';
        };

        const runDemoChat = async (prefilledMessage = null) => {
            const message = (prefilledMessage ?? messageInput.value).trim();

            if (!message) {
                messageInput.focus();
                return;
            }

            openPanel();
            appendBubble('user', escapeHtml(message));

            if (prefilledMessage === null) {
                messageInput.value = '';
            }

            setLoading(true);
            const loadingBubble = appendLoadingBubble();

            await new Promise((resolve) => setTimeout(resolve, 500));

            loadingBubble.remove();
            appendBubble('bot', escapeHtml(buildLocalReply(message)));

            setLoading(false);
            messageInput.focus();
        };

        chatToggle.addEventListener('click', openPanel);
        chatClose.addEventListener('click', closePanel);

        form.addEventListener('submit', (event) => {
            event.preventDefault();
            runDemoChat();
        });

        exampleButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const prompt = button.getAttribute('data-prompt');

                if (!prompt) {
                    return;
                }

                messageInput.value = prompt;
                runDemoChat(prompt);
            });
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && chatPanel.classList.contains('is-open')) {
                closePanel();
            }
        });
    })();
</script>
