<footer class="app-footer d-flex justify-content-between align-items-center">
    <span>WEB4014 PHP3 - Quản lý danh mục và sản phẩm</span>
    <span>{{ date('Y') }}</span>
</footer>