<header class="app-header d-flex justify-content-between align-items-center gap-3">
    <div>
        <div class="fw-semibold">@yield('page_title', 'Quản lý dữ liệu')</div>
        <div class="text-secondary small">@yield('page_subtitle', 'Danh mục và sản phẩm')</div>
    </div>
    <div class="text-secondary small">
        Cập nhật: {{ now()->format('d/m/Y H:i') }}
    </div>
</header>