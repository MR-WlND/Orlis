@extends('layouts.app')

@section('title', 'Thùng rác danh mục')
@section('page_title', 'Thùng rác danh mục')
@section('page_subtitle', 'Khôi phục hoặc xóa vĩnh viễn')

@section('content')
    <div class="panel mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h5 class="mb-0">Bộ lọc danh mục đã xóa mềm</h5>
            <a href="{{ route('categories.index') }}" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
            </a>
        </div>

        <form method="GET" action="{{ route('categories.trash') }}">
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="q" class="form-label">Từ khóa</label>
                    <input
                        type="text"
                        id="q"
                        name="q"
                        class="form-control"
                        value="{{ $filters['q'] }}"
                        placeholder="Tên, slug, mô tả..."
                    >
                </div>
                <div class="col-md-4">
                    <label for="sort" class="form-label">Sắp xếp</label>
                    <select id="sort" name="sort" class="form-select">
                        <option value="latest" @selected($filters['sort'] === 'latest')>Mới xóa gần đây</option>
                        <option value="oldest" @selected($filters['sort'] === 'oldest')>Cũ nhất</option>
                        <option value="name_asc" @selected($filters['sort'] === 'name_asc')>Tên A-Z</option>
                        <option value="name_desc" @selected($filters['sort'] === 'name_desc')>Tên Z-A</option>
                        <option value="updated_desc" @selected($filters['sort'] === 'updated_desc')>Cập nhật gần nhất</option>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end justify-content-md-end">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary icon-btn" title="Lọc dữ liệu">
                            <i class="bi bi-funnel-fill"></i>
                        </button>
                        <a href="{{ route('categories.trash') }}" class="btn btn-outline-secondary icon-btn" title="Xóa bộ lọc">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="panel">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên danh mục</th>
                    <th>Slug</th>
                    <th>Mô tả</th>
                    <th>Số sản phẩm</th>
                    <th class="text-end">Thao tác</th>
                </tr>
                </thead>
                <tbody>
                @forelse ($categories as $category)
                    <tr>
                        <td>{{ $category->id }}</td>
                        <td class="fw-semibold">{{ $category->name }}</td>
                        <td>{{ $category->slug }}</td>
                        <td>{{ \Illuminate\Support\Str::limit($category->description, 60) ?: '-' }}</td>
                        <td>{{ $category->products_count }}</td>
                        <td class="text-end">
                            <div class="table-actions">
                                <form action="{{ route('categories.restore', $category->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('PATCH')
                                    <button type="submit" class="btn btn-sm btn-outline-success icon-btn" title="Khôi phục">
                                        <i class="bi bi-arrow-counterclockwise"></i>
                                    </button>
                                </form>

                                <form
                                    action="{{ route('categories.force-delete', $category->id) }}"
                                    method="POST"
                                    class="d-inline"
                                    onsubmit="return confirm('Bạn chắc chắn muốn xóa vĩnh viễn danh mục này?');"
                                >
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger icon-btn" title="Xóa vĩnh viễn">
                                        <i class="bi bi-trash3-fill"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-secondary">Thùng rác đang trống.</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $categories->links() }}
        </div>
    </div>
@endsection
