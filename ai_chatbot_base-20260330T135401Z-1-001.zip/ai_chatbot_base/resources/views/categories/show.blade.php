@extends('layouts.app')

@section('title', 'Chi tiết danh mục')
@section('page_title', 'Chi tiết danh mục')
@section('page_subtitle', 'Xem thông tin và sản phẩm liên quan')

@section('content')
    <div class="panel mb-4">
        <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
            <div>
                <h4 class="mb-1">{{ $category->name }}</h4>
                <div class="text-secondary">Slug: {{ $category->slug }}</div>
            </div>
            <div class="d-flex gap-2">
                <a href="{{ route('categories.edit', $category) }}" class="btn btn-warning">Sửa</a>
                <a href="{{ route('categories.index') }}" class="btn btn-outline-secondary">Quay lại</a>
            </div>
        </div>

        <div class="mb-0">
            <div class="fw-semibold mb-1">Mô tả</div>
            <div>{{ $category->description ?: 'Chưa có mô tả.' }}</div>
        </div>
    </div>

    <div class="panel">
        <h5 class="mb-3">Sản phẩm thuộc danh mục</h5>

        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên sản phẩm</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th class="text-end">Thao tác</th>
                </tr>
                </thead>
                <tbody>
                @forelse ($products as $product)
                    <tr>
                        <td>{{ $product->id }}</td>
                        <td>{{ $product->name }}</td>
                        <td>{{ number_format((float) $product->price, 0, ',', '.') }} đ</td>
                        <td>{{ $product->quantity }}</td>
                        <td class="text-end">
                            <a href="{{ route('products.show', $product) }}" class="btn btn-sm btn-outline-primary">
                                Xem
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-secondary">Chưa có sản phẩm nào.</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $products->links() }}
        </div>
    </div>
@endsection