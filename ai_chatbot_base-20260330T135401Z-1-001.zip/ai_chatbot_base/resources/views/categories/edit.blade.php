@extends('layouts.app')

@section('title', 'Cập nhật danh mục')
@section('page_title', 'Cập nhật danh mục')
@section('page_subtitle', 'Chỉnh sửa thông tin danh mục')

@section('content')
    <div class="panel">
        <h5 class="mb-3">Thông tin danh mục #{{ $category->id }}</h5>

        <form action="{{ route('categories.update', $category) }}" method="POST">
            @method('PUT')
            @include('categories._form', [
                'submitLabel' => 'Cập nhật danh mục',
                'category' => $category,
            ])
        </form>
    </div>
@endsection