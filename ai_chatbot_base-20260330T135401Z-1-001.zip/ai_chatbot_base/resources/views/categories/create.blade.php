@extends('layouts.app')

@section('title', 'Thêm danh mục')
@section('page_title', 'Thêm danh mục')
@section('page_subtitle', 'Tạo mới danh mục sản phẩm')

@section('content')
    <div class="panel">
        <h5 class="mb-3">Thông tin danh mục</h5>

        <form action="{{ route('categories.store') }}" method="POST">
            @include('categories._form', ['submitLabel' => 'Lưu danh mục'])
        </form>
    </div>
@endsection