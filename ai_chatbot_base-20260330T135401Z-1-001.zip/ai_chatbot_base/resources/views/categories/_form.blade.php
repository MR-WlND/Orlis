@csrf

<div class="mb-3">
    <label for="name" class="form-label">Tên danh mục <span class="text-danger">*</span></label>
    <input
        type="text"
        id="name"
        name="name"
        class="form-control @error('name') is-invalid @enderror"
        value="{{ old('name', $category->name ?? '') }}"
        required
    >
    @error('name')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<div class="mb-3">
    <label for="slug" class="form-label">Slug (tự động theo tên)</label>
    <input
        type="text"
        id="slug"
        name="slug"
        class="form-control"
        value="{{ old('slug', $category->slug ?? '') }}"
        readonly
    >
</div>

<div class="mb-3">
    <label for="description" class="form-label">Mô tả</label>
    <textarea
        id="description"
        name="description"
        class="form-control @error('description') is-invalid @enderror"
        rows="4"
    >{{ old('description', $category->description ?? '') }}</textarea>
    @error('description')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<div class="d-flex gap-2">
    <button type="submit" class="btn btn-primary">{{ $submitLabel }}</button>
    <a href="{{ route('categories.index') }}" class="btn btn-outline-secondary">Quay lại</a>
</div>

@push('scripts')
<script>
    (function () {
        const nameInput = document.getElementById('name');
        const slugInput = document.getElementById('slug');

        if (!nameInput || !slugInput) {
            return;
        }

        const slugify = (value) => value
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/g, 'd')
            .replace(/[^a-z0-9\s-]/g, '')
            .trim()
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-');

        const syncSlug = () => {
            slugInput.value = slugify(nameInput.value);
        };

        if (!slugInput.value) {
            syncSlug();
        }

        nameInput.addEventListener('input', syncSlug);
    })();
</script>
@endpush