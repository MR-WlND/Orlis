﻿@extends('layouts.client')

@section('title', 'Chi tiết sản phẩm')

@push('styles')
<style>
    .detail-card {
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        overflow: hidden;
    }

    .product-image {
        width: 100%;
        height: 100%;
        min-height: 320px;
        object-fit: cover;
        background: #eef2ff;
    }

    .meta-label {
        font-size: 13px;
        color: #6b7280;
    }
</style>
@endpush

@section('content')
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h2 class="mb-1">Chi tiết sản phẩm</h2>
            <div class="text-secondary">Thông tin chi tiết dành cho khách hàng</div>
        </div>
        <a href="{{ route('client.products.index') }}" class="btn btn-outline-secondary">Quay lại danh sách</a>
    </div>

    <div class="card detail-card shadow-sm border-0">
        <div class="row g-0">
            <div class="col-lg-5">
                @if ($product->image)
                    <img
                        src="{{ asset('storage/' . $product->image) }}"
                        alt="{{ $product->name }}"
                        class="product-image"
                    >
                @else
                    <div class="product-image d-flex align-items-center justify-content-center text-secondary">
                        Chưa có ảnh sản phẩm
                    </div>
                @endif
            </div>
            <div class="col-lg-7">
                <div class="card-body p-4 p-md-5">
                    <div class="mb-2 text-secondary">{{ $product->category?->name }}</div>
                    <h3 class="mb-3">{{ $product->name }}</h3>

                    <div class="h4 text-primary mb-4">
                        {{ number_format((float) $product->price, 0, ',', '.') }} VND
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-sm-6">
                            <div class="border rounded p-3 h-100">
                                <div class="meta-label mb-1">Số lượng còn lại</div>
                                <div class="fw-semibold">{{ $product->quantity }} sản phẩm</div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="border rounded p-3 h-100">
                                <div class="meta-label mb-1">Mã slug</div>
                                <div class="fw-semibold">{{ $product->slug }}</div>
                            </div>
                        </div>
                    </div>

                    <div class="border rounded p-3 mb-4">
                        <div class="meta-label mb-2">Mô tả sản phẩm</div>
                        <div>{{ $product->description ?: 'Sản phẩm chưa có mô tả.' }}</div>
                    </div>

                    <a href="{{ route('client.products.index') }}" class="btn btn-primary">
                        Về trang danh sách sản phẩm
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection
