﻿@extends('layouts.client')

@section('title', 'Danh sách sản phẩm')

@push('styles')
<style>
    .product-card {
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        transition: 0.2s ease;
        height: 100%;
    }

    .product-card:hover {
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
        transform: translateY(-2px);
    }

    .product-link {
        color: inherit;
        text-decoration: none;
        display: block;
        height: 100%;
    }

    .product-image {
        height: 180px;
        object-fit: cover;
        border-top-left-radius: 14px;
        border-top-right-radius: 14px;
        background: #eef2ff;
    }

    .icon-btn {
        width: 40px;
        height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0;
    }
</style>
@endpush

@section('content')
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div>
            <h2 class="mb-1">Danh sách sản phẩm</h2>
            <div class="text-secondary">Hiển thị toàn bộ sản phẩm cho khách hàng</div>
        </div>
        <a href="{{ route('categories.index') }}" class="btn btn-outline-primary">Vào trang quản trị</a>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('client.products.index') }}">
                <div class="row g-3 align-items-end">
                    <div class="col-md-5">
                        <label for="q" class="form-label">Từ khóa</label>
                        <input
                            type="text"
                            id="q"
                            name="q"
                            class="form-control"
                            value="{{ $filters['q'] }}"
                            placeholder="Tên sản phẩm, slug, mô tả..."
                        >
                    </div>
                    <div class="col-md-3">
                        <label for="category_id" class="form-label">Danh mục</label>
                        <select id="category_id" name="category_id" class="form-select">
                            <option value="">-- Tất cả danh mục --</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}" @selected((string) $filters['category_id'] === (string) $category->id)>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="sort" class="form-label">Sắp xếp</label>
                        <select id="sort" name="sort" class="form-select">
                            <option value="latest" @selected($filters['sort'] === 'latest')>Mới nhất</option>
                            <option value="oldest" @selected($filters['sort'] === 'oldest')>Cũ nhất</option>
                            <option value="name_asc" @selected($filters['sort'] === 'name_asc')>Tên A-Z</option>
                            <option value="name_desc" @selected($filters['sort'] === 'name_desc')>Tên Z-A</option>
                            <option value="price_asc" @selected($filters['sort'] === 'price_asc')>Giá tăng dần</option>
                            <option value="price_desc" @selected($filters['sort'] === 'price_desc')>Giá giảm dần</option>
                        </select>
                    </div>
                    <div class="col-md-1 d-flex align-items-end justify-content-md-end">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary icon-btn" title="Lọc sản phẩm" aria-label="Lọc sản phẩm">
                                <i class="bi bi-funnel-fill"></i>
                            </button>
                            <a
                                href="{{ route('client.products.index') }}"
                                class="btn btn-outline-secondary icon-btn"
                                title="Xóa bộ lọc"
                                aria-label="Xóa bộ lọc"
                            >
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-4">
        @forelse ($products as $product)
            <div class="col-12 col-sm-6 col-lg-4">
                <a href="{{ route('client.products.show', $product->slug) }}" class="product-link">
                    <div class="card product-card">
                        @if ($product->image)
                            <img
                                src="{{ asset('storage/' . $product->image) }}"
                                alt="{{ $product->name }}"
                                class="product-image w-100"
                            >
                        @else
                            <div class="product-image d-flex align-items-center justify-content-center text-secondary">
                                Chưa có ảnh
                            </div>
                        @endif
                        <div class="card-body">
                            <div class="text-secondary small mb-2">{{ $product->category?->name }}</div>
                            <h5 class="card-title mb-2">{{ $product->name }}</h5>
                            <div class="fw-bold text-primary mb-2">
                                {{ number_format((float) $product->price, 0, ',', '.') }} VND
                            </div>
                            <p class="card-text text-secondary mb-3">
                                {{ \Illuminate\Support\Str::limit($product->description, 90) ?: 'Không có mô tả.' }}
                            </p>
                            <div class="small text-secondary mb-0">Còn lại: {{ $product->quantity }} sản phẩm</div>
                        </div>
                    </div>
                </a>
            </div>
        @empty
            <div class="col-12">
                <div class="alert alert-warning mb-0">Không tìm thấy sản phẩm phù hợp.</div>
            </div>
        @endforelse
    </div>

    <div class="mt-4">
        {{ $products->links() }}
    </div>
@endsection
