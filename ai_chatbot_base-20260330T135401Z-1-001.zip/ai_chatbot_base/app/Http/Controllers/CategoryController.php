<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class CategoryController extends Controller
{
    /**
     * Display active categories with search/filter support.
     */
    public function index(Request $request): View
    {
        $q = trim((string) $request->input('q', ''));
        $sort = (string) $request->input('sort', 'latest');

        $query = Category::query()->withCount('products');
        $this->applyFilters($query, $q, $sort);

        $categories = $query->paginate(10)->withQueryString();

        return view('categories.index', [
            'categories' => $categories,
            'filters' => [
                'q' => $q,
                'sort' => $sort,
            ],
        ]);
    }

    /**
     * Display trashed categories.
     */
    public function trash(Request $request): View
    {
        $q = trim((string) $request->input('q', ''));
        $sort = (string) $request->input('sort', 'latest');

        $query = Category::onlyTrashed()->withCount('products');
        $this->applyFilters($query, $q, $sort);

        $categories = $query->paginate(10)->withQueryString();

        return view('categories.trash', [
            'categories' => $categories,
            'filters' => [
                'q' => $q,
                'sort' => $sort,
            ],
        ]);
    }

    /**
     * Show the form for creating a new category.
     */
    public function create(): View
    {
        return view('categories.create');
    }

    /**
     * Store a newly created category in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $validated['slug'] = $this->generateUniqueSlug($validated['name']);

        Category::create($validated);

        return redirect()
            ->route('categories.index')
            ->with('success', 'Thêm danh mục thành công.');
    }

    /**
     * Display the specified category.
     */
    public function show(Category $category): View
    {
        $products = $category
            ->products()
            ->latest()
            ->paginate(10);

        return view('categories.show', [
            'category' => $category,
            'products' => $products,
        ]);
    }

    /**
     * Show the form for editing the specified category.
     */
    public function edit(Category $category): View
    {
        return view('categories.edit', [
            'category' => $category,
        ]);
    }

    /**
     * Update the specified category in storage.
     */
    public function update(Request $request, Category $category): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $validated['slug'] = $this->generateUniqueSlug($validated['name'], $category->id);

        $category->update($validated);

        return redirect()
            ->route('categories.index')
            ->with('success', 'Cập nhật danh mục thành công.');
    }

    /**
     * Soft delete the specified category.
     */
    public function destroy(Category $category): RedirectResponse
    {
        $category->delete();

        return redirect()
            ->route('categories.index')
            ->with('success', 'Đã xóa mềm danh mục.');
    }

    /**
     * Restore the soft-deleted category.
     */
    public function restore(int $id): RedirectResponse
    {
        $category = Category::onlyTrashed()->findOrFail($id);
        $category->restore();

        return redirect()
            ->route('categories.trash')
            ->with('success', 'Khôi phục danh mục thành công.');
    }

    /**
     * Permanently delete the soft-deleted category.
     */
    public function forceDelete(int $id): RedirectResponse
    {
        $category = Category::onlyTrashed()->findOrFail($id);
        $category->forceDelete();

        return redirect()
            ->route('categories.trash')
            ->with('success', 'Đã xóa vĩnh viễn danh mục.');
    }

    /**
     * Apply shared filters for category listing queries.
     */
    private function applyFilters(Builder $query, string $q, string $sort): void
    {
        if ($q !== '') {
            $query->where(function (Builder $builder) use ($q): void {
                $builder
                    ->where('name', 'like', '%' . $q . '%')
                    ->orWhere('slug', 'like', '%' . $q . '%')
                    ->orWhere('description', 'like', '%' . $q . '%');
            });
        }

        match ($sort) {
            'name_asc' => $query->orderBy('name'),
            'name_desc' => $query->orderByDesc('name'),
            'oldest' => $query->orderBy('created_at'),
            'updated_desc' => $query->orderByDesc('updated_at'),
            default => $query->orderByDesc('created_at'),
        };
    }

    /**
     * Generate a unique slug from category name.
     */
    private function generateUniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name);
        $base = $base !== '' ? $base : 'danh-muc';
        $slug = $base;
        $counter = 2;

        while (
            Category::withTrashed()
                ->where('slug', $slug)
                ->when($ignoreId, fn (Builder $builder) => $builder->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $slug = $base . '-' . $counter;
            $counter++;
        }

        return $slug;
    }
}