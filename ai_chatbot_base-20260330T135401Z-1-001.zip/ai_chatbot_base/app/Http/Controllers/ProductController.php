<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ProductController extends Controller
{
    /**
     * Display active products with search/filter support.
     */
    public function index(Request $request): View
    {
        $filters = $this->collectFilters($request);

        $query = Product::query()->with([
            'category' => fn ($relation) => $relation->withTrashed(),
        ]);

        $this->applyFilters($query, $filters);

        $products = $query->paginate(10)->withQueryString();
        $categories = Category::withTrashed()->orderBy('name')->get(['id', 'name', 'deleted_at']);

        return view('products.index', [
            'products' => $products,
            'categories' => $categories,
            'filters' => $filters,
        ]);
    }

    /**
     * Display trashed products.
     */
    public function trash(Request $request): View
    {
        $filters = $this->collectFilters($request);

        $query = Product::onlyTrashed()->with([
            'category' => fn ($relation) => $relation->withTrashed(),
        ]);

        $this->applyFilters($query, $filters);

        $products = $query->paginate(10)->withQueryString();
        $categories = Category::withTrashed()->orderBy('name')->get(['id', 'name', 'deleted_at']);

        return view('products.trash', [
            'products' => $products,
            'categories' => $categories,
            'filters' => $filters,
        ]);
    }

    /**
     * Show the form for creating a new product.
     */
    public function create(): View
    {
        $categories = Category::query()->orderBy('name')->get(['id', 'name']);

        return view('products.create', [
            'categories' => $categories,
        ]);
    }

    /**
     * Store a newly created product in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'price' => ['required', 'numeric', 'min:0'],
            'quantity' => ['required', 'integer', 'min:0'],
            'image_file' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp,gif', 'max:2048'],
            'category_id' => ['required', Rule::exists('categories', 'id')->whereNull('deleted_at')],
        ]);

        $validated['slug'] = $this->generateUniqueSlug($validated['name']);

        if ($request->hasFile('image_file')) {
            $validated['image'] = $request->file('image_file')->store('products', 'public');
        } else {
            $validated['image'] = null;
        }

        unset($validated['image_file']);

        Product::create($validated);

        return redirect()
            ->route('products.index')
            ->with('success', 'Thêm sản phẩm thành công.');
    }

    /**
     * Display the specified product.
     */
    public function show(Product $product): View
    {
        $product->load([
            'category' => fn ($relation) => $relation->withTrashed(),
        ]);

        return view('products.show', [
            'product' => $product,
        ]);
    }

    /**
     * Show the form for editing the specified product.
     */
    public function edit(Product $product): View
    {
        $categories = Category::withTrashed()
            ->where(function (Builder $builder) use ($product): void {
                $builder
                    ->whereNull('deleted_at')
                    ->orWhere('id', $product->category_id);
            })
            ->orderBy('name')
            ->get(['id', 'name', 'deleted_at']);

        return view('products.edit', [
            'product' => $product,
            'categories' => $categories,
        ]);
    }

    /**
     * Update the specified product in storage.
     */
    public function update(Request $request, Product $product): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'price' => ['required', 'numeric', 'min:0'],
            'quantity' => ['required', 'integer', 'min:0'],
            'image_file' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp,gif', 'max:2048'],
            'category_id' => [
                'required',
                'integer',
                Rule::exists('categories', 'id')->where(function ($query) use ($product): void {
                    $query
                        ->whereNull('deleted_at')
                        ->orWhere('id', $product->category_id);
                }),
            ],
        ]);

        $validated['slug'] = $this->generateUniqueSlug($validated['name'], $product->id);

        if ($request->hasFile('image_file')) {
            if (! empty($product->image) && Storage::disk('public')->exists($product->image)) {
                Storage::disk('public')->delete($product->image);
            }

            $validated['image'] = $request->file('image_file')->store('products', 'public');
        } else {
            $validated['image'] = $product->image;
        }

        unset($validated['image_file']);

        $product->update($validated);

        return redirect()
            ->route('products.index')
            ->with('success', 'Cập nhật sản phẩm thành công.');
    }

    /**
     * Soft delete the specified product.
     */
    public function destroy(Product $product): RedirectResponse
    {
        $product->delete();

        return redirect()
            ->route('products.index')
            ->with('success', 'Đã xóa mềm sản phẩm.');
    }

    /**
     * Restore the soft-deleted product.
     */
    public function restore(int $id): RedirectResponse
    {
        $product = Product::onlyTrashed()->findOrFail($id);
        $product->restore();

        return redirect()
            ->route('products.trash')
            ->with('success', 'Khôi phục sản phẩm thành công.');
    }

    /**
     * Permanently delete the soft-deleted product.
     */
    public function forceDelete(int $id): RedirectResponse
    {
        $product = Product::onlyTrashed()->findOrFail($id);

        if (! empty($product->image) && Storage::disk('public')->exists($product->image)) {
            Storage::disk('public')->delete($product->image);
        }

        $product->forceDelete();

        return redirect()
            ->route('products.trash')
            ->with('success', 'Đã xóa vĩnh viễn sản phẩm.');
    }

    /**
     * Collect filters from request.
     *
     * @return array<string, string>
     */
    private function collectFilters(Request $request): array
    {
        return [
            'q' => trim((string) $request->input('q', '')),
            'sort' => (string) $request->input('sort', 'latest'),
            'category_id' => (string) $request->input('category_id', ''),
        ];
    }

    /**
     * Apply shared filters for product listing queries.
     *
     * @param array<string, string> $filters
     */
    private function applyFilters(Builder $query, array $filters): void
    {
        if ($filters['q'] !== '') {
            $q = $filters['q'];
            $query->where(function (Builder $builder) use ($q): void {
                $builder
                    ->where('name', 'like', '%' . $q . '%')
                    ->orWhere('slug', 'like', '%' . $q . '%')
                    ->orWhere('description', 'like', '%' . $q . '%');
            });
        }

        if ($filters['category_id'] !== '' && ctype_digit($filters['category_id'])) {
            $query->where('category_id', (int) $filters['category_id']);
        }

        match ($filters['sort']) {
            'name_asc' => $query->orderBy('name'),
            'name_desc' => $query->orderByDesc('name'),
            'price_asc' => $query->orderBy('price'),
            'price_desc' => $query->orderByDesc('price'),
            'quantity_asc' => $query->orderBy('quantity'),
            'quantity_desc' => $query->orderByDesc('quantity'),
            'oldest' => $query->orderBy('created_at'),
            'updated_desc' => $query->orderByDesc('updated_at'),
            default => $query->orderByDesc('created_at'),
        };
    }

    /**
     * Generate a unique slug from product name.
     */
    private function generateUniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name);
        $base = $base !== '' ? $base : 'san-pham';
        $slug = $base;
        $counter = 2;

        while (
            Product::withTrashed()
                ->where('slug', $slug)
                ->when($ignoreId, fn (Builder $builder) => $builder->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $slug = $base . '-' . $counter;
            $counter++;
        }

        return $slug;
    }
}