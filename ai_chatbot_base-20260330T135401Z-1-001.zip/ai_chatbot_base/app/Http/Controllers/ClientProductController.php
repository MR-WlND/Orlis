<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ClientProductController extends Controller
{
    /**
     * Display product listing for client side.
     */
    public function index(Request $request): View
    {
        $q = trim((string) $request->input('q', ''));
        $sort = (string) $request->input('sort', 'latest');
        $categoryId = (string) $request->input('category_id', '');

        $query = Product::query()
            ->with('category')
            ->whereHas('category');

        if ($q !== '') {
            $query->where(function (Builder $builder) use ($q): void {
                $builder
                    ->where('name', 'like', '%' . $q . '%')
                    ->orWhere('slug', 'like', '%' . $q . '%')
                    ->orWhere('description', 'like', '%' . $q . '%');
            });
        }

        if ($categoryId !== '' && ctype_digit($categoryId)) {
            $query->where('category_id', (int) $categoryId);
        }

        match ($sort) {
            'name_asc' => $query->orderBy('name'),
            'name_desc' => $query->orderByDesc('name'),
            'price_asc' => $query->orderBy('price'),
            'price_desc' => $query->orderByDesc('price'),
            'oldest' => $query->orderBy('created_at'),
            default => $query->orderByDesc('created_at'),
        };

        $products = $query->paginate(12)->withQueryString();
        $categories = Category::query()->orderBy('name')->get(['id', 'name']);

        return view('client.products.index', [
            'products' => $products,
            'categories' => $categories,
            'filters' => [
                'q' => $q,
                'sort' => $sort,
                'category_id' => $categoryId,
            ],
        ]);
    }

    /**
     * Display product detail for client side.
     */
    public function show(string $slug): View
    {
        $product = Product::query()
            ->with('category')
            ->whereHas('category')
            ->where('slug', $slug)
            ->firstOrFail();

        return view('client.products.show', [
            'product' => $product,
        ]);
    }
}
